a=1.10; %CG front
b=1.60; %CG rear
% Tire cornering stiffness
Caf=142000;
Car=142000;
m=500; % Mass
Iz=1000; % Moment of Inertia
vx=16; % Longitudinal Speed
delta=11; %Steering input to front wheel in deg

L = a+b;
W = m*9.81;
g = 9.81;

C_beta = -(Car + Caf);
C_r = (-a*Caf/vx) + (b*Car/vx);
D_beta = -((a*Caf)-(b*Car));
D_r = -(a*a*Caf+b*b*Car)/vx;
C_delta = Caf;
D_delta = a*Caf;

A = [2*C_beta/(m) , 2*(C_r/m)-vx;...
    2*D_beta/(Iz) , 2*D_r/Iz];

B = [2*C_delta/m ; 2*D_delta/Iz];
C = [1 0 ; 0 1];
D = [0;0];

Wf = W*b/(b+a);
Wr = W*a/(b+a);

Kv = Wf/(2*Caf) - Wr/(2*Car);

fprintf('The value of Kv is %.4f\n', Kv);


%Calculating Steady State Gain
a1 = vx/(L*(1+(Kv*vx^2)/(L*g)));
fprintf('The value of Steady State Gain is %.4f\n', a1);

%Calculating Natural Frequency of yaw velocity response
f = (L/(pi*vx))*(Caf*Car*(1+(Kv*vx^2)/(L*g))/(m*Iz))^0.5;
fprintf('The value of Natural Frequency of Yaw rate is %.4f\n', f);

% Numerator computation
num = (Caf + Car) / (m * vx) + (Caf*a*a + Car*b*b) / (Iz * vx);

% Denominator computation
den = 2*pi*f;

% Damping ratio
zeta = num / den;

% Display result
fprintf('Damping Ratio (ξ) = %.4f\n', zeta);

% Phase delay calculation
term1 = atan( (2 * Car * b * L) / ((2 * Car * L * vx) - (Iz * vx)) );
term2 = atan( (2 * zeta * 2*pi*f) / ((f*2*pi)^2 - 1) );

phi = term1 - term2;

% Display the result
fprintf('Phase Delay (ϕ) = %.4f radians\n', phi);
fprintf('Phase Delay (ϕ) = %.2f degrees\n', rad2deg(phi));

% Given values
steady_state_gain = 5.7482;      % a1
natural_frequency = 10.9524;     % omega_n
damping_ratio = 1.0021;          % ξ
phase_delay = 4.05;              % ϕ (degrees)

% Define points for each parameter in (X, Y)
point_phase_delay      = [phase_delay, 0];              % +X axis
point_steady_gain      = [-steady_state_gain, 0];       % -X axis
point_natural_frequency= [0, natural_frequency];        % +Y axis
point_damping_ratio    = [0, -damping_ratio];           % -Y axis

% Create array for the quadrilateral vertices, looping back to start
points = [
    point_phase_delay;
    point_natural_frequency;
    point_steady_gain;
    point_damping_ratio;
    point_phase_delay % Close the loop
];

% Plot
figure;
hold on;
grid on;
axis equal;

% Draw X and Y axes
plot([-steady_state_gain-5, phase_delay+5], [0, 0], 'k--', 'LineWidth', 1);  % X-axis
plot([0, 0], [-damping_ratio-5, natural_frequency+5], 'k--', 'LineWidth', 1); % Y-axis

% Plot the quadrilateral
plot(points(:,1), points(:,2), 'k-o', 'LineWidth', 2, 'MarkerSize', 8, 'MarkerFaceColor', 'y');

% Annotate each point
text(point_phase_delay(1)+0.3, point_phase_delay(2), sprintf('ϕ = %.2f°', phase_delay), 'Color', 'r', 'FontSize', 12);
text(point_steady_gain(1)-1, point_steady_gain(2), sprintf('a₁ = %.2f', steady_state_gain), 'Color', 'b', 'FontSize', 12);
text(point_natural_frequency(1)+0.3, point_natural_frequency(2)+0.5, sprintf('fₙ = %.2f', natural_frequency), 'Color', 'g', 'FontSize', 12);
text(point_damping_ratio(1)+0.3, point_damping_ratio(2)-0.5, sprintf('ξ = %.4f', damping_ratio), 'Color', 'm', 'FontSize', 12);

% Labels and Title
xlabel('Phase Delay → | ← Steady State Gain', 'FontSize', 12);
ylabel('Natural Frequency ↑ | ↓ Damping Ratio', 'FontSize', 12);
title('Mimuro Plot: Vehicle Handling Characteristics', 'FontSize', 14);

% Magnify plot view for clarity
xlim([-steady_state_gain-3, phase_delay+3]);
ylim([-damping_ratio-3, natural_frequency+3]);

hold off;

%Calculating Radius of Curvature
R = (L + (Kv*vx^2/g))*180/(delta*pi);
fprintf('Radius of Curvature = %.4f\n', R);
    