a = 1.10; % Distance from CG to front axle [m]
b = 1.60; % Distance from CG to rear axle [m]

% Tire cornering stiffness
Caf = 142000;
Car = 142000;

% Vehicle properties
m = 500;      % Mass [kg]
Iz = 1000;    % Yaw Moment of Inertia [kg·m²]
vx = 16;      % Constant longitudinal speed [m/s]
delta = 11;   % Steering input in degrees

% State-space matrices calculations
C_beta = -(Car + Caf);
C_r = (-a*Caf / vx) + (b*Car / vx);
D_beta = -((a*Caf) - (b*Car));
D_r = -(a^2 * Caf + b^2 * Car) / vx;
C_delta = Caf;
D_delta = a * Caf;

A = [ (2 * C_beta) / (m * vx),  (2 * C_r / m) - vx;
      (2 * D_beta) / (Iz * vx), 2 * D_r / Iz ];

B = [2 * C_delta / m; 2 * D_delta / Iz];
C = [1, 0; 0, 1];
D = [0; 0];

% Time vector
t = 0:0.01:30;
figure;
plot(t,out.r_local.Data);
figure;
plot(t,out.vy_local.Data);

% Simulated data (assuming you've already run your Simulink model):
yaw_rate = out.r_local.Data;
vy_local = out.vy_local.Data;



% Preallocate global velocity arrays
vy_global = zeros(1, length(yaw_rate));
vx_global = zeros(1, length(yaw_rate));

% Integrate yaw rate to obtain yaw angle
yaw = cumtrapz(t, yaw_rate);

% Transform from local to global frame
for k = 1:length(yaw_rate)
    R = [cos(yaw(k)), -sin(yaw(k));
         sin(yaw(k)),  cos(yaw(k))];
    temp = R' * [vy_local(k); vx];  % Correct rotation: local -> global
    vy_global(k) = temp(1);
    vx_global(k) = temp(2);
end

% Prepare time-aligned output arrays
vy_g = [t; vy_global]';
vy_l = [t; vy_local']';

% Extract accelerations from simulation
ay_g = out.ay_global.Data(:,1);
ay_l = out.ay_local.Data(:,1);

% === Plot: Global Lateral Acceleration ===
figure;
plot(t, ay_g, 'b', 'LineWidth', 2);
xlabel('Time (s)');
ylabel('Global Lateral Acceleration (m/s²)');
title('Global Lateral Acceleration (a_{y_g})');
grid on;

% === Plot: Local Lateral Acceleration ===
figure;
plot(t, ay_l, 'r', 'LineWidth', 2);
xlabel('Time (s)');
ylabel('Local Lateral Acceleration (m/s²)');
title('Local Lateral Acceleration (a_{y_l})');
grid on;

