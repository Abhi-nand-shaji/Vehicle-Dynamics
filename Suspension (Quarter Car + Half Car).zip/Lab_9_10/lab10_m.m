
c1 = 0;
c2 = 0;

m = 840/2;
m1 = 53;
m2 = 152/2;

Iy = 1100;

a1 = 1.4;
a2 = 1.47;

k1 = 10000;
k2 = 13000;

kt1 = 200000;
kt2 = 200000;


M = [m 0 0 0; 0 Iy 0 0; 0 0 m1 0; 0 0 0 m2];


C = [c1+c2 a2*c2-a1*c1 -c1 -c2; -a1*c1+a2*c2 c1*a1^2+c2*a2^2 a1*c1 -a2*c2; -c1 a1*c1 c1 0; -c2 -a2*c2 0 c2];
K = [k1+k2 a2*k2-a1*k1 -k1 -k2; a2*k2-a1*k1 k1*a1^2+k2*a2^2 a1*k1 -a2*k2; -k1 a1*k1 k1+kt1 0; -k2 -a2*k2 0 k2+kt2];

A = inv(M)*K;
Omega2 = eig(A);
Nat_freq = sqrt(Omega2);

fprintf('',Nat_freq)

ms = 375;
mu = 75;
M1 = [ms 0; 0 mu];

bs = 0;
C1 = [bs -bs; -bs bs];

kt = 193000;
ks = 35000;
K1 = [ks -ks; -ks (ks+kt)];

A1 = inv(M1)*K1;
omega2 = eig(A1);
Nat_freq_1 = sqrt(omega2);
fprintf('',Nat_freq_1);

M2 = [m 0; 0 Iy];
K2 = [k1+k2 k2*a2-k1*a1; k2*a2-k1*a1 k1*a1^2+k2*a2^2];
A2 = inv(M2)*K2;
pmega2 = eig(A2);
Nat_freq_2 = sqrt(pmega2);
fprintf('',Nat_freq_2);





